# SNRZ AI V6 — SNRZ ONLY

A SNRZ-only XAU/USD analysis backend.

### Features
- Multi-timeframe OHLC analysis
- Automatic S/R candidate detection
- V.S / V.R candidates
- RBS / SBR candidates
- PO2 candidate detection
- Liquidity Sweep / Run candidates
- Market Structure
- SNRZ-only terminology
- Paper / educational mode

### Deployment
This package is ready for a Vercel Python serverless deployment.

Set `TWELVE_DATA_API_KEY` as a private environment variable. Do not put a real API key in GitHub.

### No unrelated indicators
The core engine intentionally excludes ICT, SMC, RSI, MACD and other non-SNRZ systems.
