# SNRZ AI V6 — SNRZ ONLY

This project is intentionally restricted to the supplied SNRZ terminology and framework.

## Core SNRZ concepts
V.S, V.R, I-VS, I-VR, SBR, RBS, SRR, RSS, PO2, Liquidity Sweep, Liquidity Run, False Breakout, Market Structure, Gap Strategy, Pump Base, Dump Base, and Zindan's Wave.

## Timeframes
The supplied material contains a higher-timeframe analysis chain and lower-timeframe confirmation concepts. V6 therefore reads:
Monthly, Weekly, Daily, H4, H1, M30, M15, M5, M1.

## Important limitation
The PDF material does not provide a complete numerical algorithm for every visual classification. Therefore V6 marks automatic OHLC classifications as candidates rather than pretending they are fully PDF-confirmed.

## Excluded from the core
ICT, SMC, RSI, MACD, and unrelated indicators are not used as SNRZ rules.

## Safety
Paper/educational analysis only. No broker connection or live order execution.
