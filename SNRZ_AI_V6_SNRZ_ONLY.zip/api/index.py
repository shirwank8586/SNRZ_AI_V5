import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fastapi import FastAPI, HTTPException, Query
from market import candles
from snrz_engine import Candle, analyze, multi_timeframe

app = FastAPI(title="SNRZ AI V6", version="6.0")

@app.get("/api/health")
def health():
    return {
        "ok": True,
        "engine": "SNRZ AI V6",
        "method": "SNRZ-only",
        "mode": "paper/educational"
    }

@app.get("/api/candles")
async def get_candles(
    interval: str = Query("15m"),
    outputsize: int = Query(250, ge=20, le=500)
):
    try:
        return {
            "symbol": "XAU/USD",
            "interval": interval,
            "values": await candles(interval, outputsize)
        }
    except Exception as e:
        raise HTTPException(status_code=502, detail=str(e))

@app.get("/api/analyze")
async def analyze_one(interval: str = Query("15m")):
    try:
        raw = await candles(interval, 250)
        return analyze([Candle(**x) for x in raw], interval)
    except Exception as e:
        raise HTTPException(status_code=502, detail=str(e))

@app.get("/api/multi-analysis")
async def multi_analysis():
    all_data = {}
    result = {}

    # SNRZ timeframe chain from the supplied material.
    for iv in ["1mo", "1w", "1d", "4h", "1h", "30m", "15m", "5m", "1m"]:
        try:
            raw = await candles(iv, 250)
            cs = [Candle(**x) for x in raw]
            all_data[iv] = cs
            result[iv] = analyze(cs, iv)
        except Exception as e:
            result[iv] = {"status": "ERROR", "error": str(e)}

    summary = multi_timeframe(all_data) if all_data else {
        "structure_alignment": "NO_DATA",
        "timeframes": {}
    }

    return {
        "symbol": "XAU/USD",
        "engine": "SNRZ AI V6",
        "method": "SNRZ-only",
        "mode": "paper/educational",
        "structure_alignment": summary.get("structure_alignment"),
        "timeframes": summary.get("timeframes", {}),
        "analysis": result,
        "ruleset": [
            "V.S", "V.R", "I-VS", "I-VR",
            "RBS", "SBR", "SRR", "RSS", "PO2",
            "Liquidity Sweep", "Liquidity Run",
            "False Breakout", "Market Structure",
            "Gap Strategy", "Pump Base", "Dump Base",
            "Zindan's Wave"
        ],
        "exclusions": ["ICT", "SMC", "RSI", "MACD"]
    }
