from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import List, Dict, Optional

# SNRZ-only terminology.
BUY_ZONES = {"V.S", "I-VR", "RBS", "SRR", "PO2"}
SELL_ZONES = {"V.R", "I-VS", "SBR", "RSS"}

@dataclass
class Candle:
    time: str
    open: float
    high: float
    low: float
    close: float

def bull(c): return c.close > c.open
def bear(c): return c.close < c.open

def pivots(cs, left=2, right=2):
    highs, lows = [], []
    for i in range(left, len(cs) - right):
        window = cs[i-left:i+right+1]
        if cs[i].high >= max(x.high for x in window):
            highs.append((i, cs[i].high))
        if cs[i].low <= min(x.low for x in window):
            lows.append((i, cs[i].low))
    return highs, lows

def structure(cs: List[Candle], lookback=100):
    c = cs[-lookback:]
    if len(c) < 10:
        return {"trend": "INSUFFICIENT_DATA", "hh": 0, "hl": 0, "lh": 0, "ll": 0}

    hs, ls = pivots(c)
    hh = lh = hl = ll = 0

    for a, b in zip(hs, hs[1:]):
        hh += b[1] > a[1]
        lh += b[1] < a[1]

    for a, b in zip(ls, ls[1:]):
        hl += b[1] > a[1]
        ll += b[1] < a[1]

    if hh + hl > lh + ll and hh and hl:
        trend = "BULLISH"
    elif lh + ll > hh + hl and lh and ll:
        trend = "BEARISH"
    else:
        trend = "RANGE/UNCLEAR"

    return {
        "trend": trend,
        "hh": hh, "hl": hl, "lh": lh, "ll": ll,
        "pivot_highs": len(hs), "pivot_lows": len(ls)
    }

def engulfing(cs):
    if len(cs) < 2:
        return {"bullish": False, "bearish": False}

    a, b = cs[-2], cs[-1]
    return {
        "bullish": bear(a) and bull(b) and b.open <= a.close and b.close >= a.open,
        "bearish": bull(a) and bear(b) and b.open >= a.close and b.close <= a.open
    }

def level_candidates(cs, tolerance=0.0012, min_touches=2):
    if len(cs) < 15:
        return []

    hs, ls = pivots(cs)
    raw = []

    for kind, pts in (("S", ls), ("R", hs)):
        for idx, level in pts:
            touches = []
            for j, c in enumerate(cs):
                value = c.low if kind == "S" else c.high
                if abs(value - level) / max(abs(level), 1e-9) <= tolerance:
                    touches.append(j)

            if len(touches) >= min_touches:
                raw.append({
                    "base": kind,
                    "level": level,
                    "touches": len(touches),
                    "first_touch": touches[0],
                    "last_touch": touches[-1]
                })

    raw.sort(key=lambda z: (-z["touches"], abs(z["level"] - cs[-1].close)))

    zones = []
    for z in raw:
        if any(
            abs(z["level"] - u["level"]) / max(abs(z["level"]), 1e-9) <= tolerance
            for u in zones
        ):
            continue
        zones.append(z)

    return zones[:20]

def classify_zones(cs, zones):
    result = []

    for z in zones:
        level = z["level"]
        last = z["last_touch"]
        typ = "S/R CANDIDATE"

        # Candidate V.S / V.R from repeated reaction evidence.
        later = cs[last+1:] if last + 1 < len(cs) else []
        reaction_up = any(c.close > level for c in later[-12:])
        reaction_down = any(c.close < level for c in later[-12:])

        if z["base"] == "S" and reaction_up:
            typ = "V.S"
        elif z["base"] == "R" and reaction_down:
            typ = "V.R"

        # SBR / RBS candidate requires a candle CLOSE across the level.
        for k in range(max(1, last - 8), min(len(cs), last + 12)):
            prev, cur = cs[k-1], cs[k]

            if z["base"] == "S" and prev.close >= level and cur.close < level:
                typ = "SBR"
                break

            if z["base"] == "R" and prev.close <= level and cur.close > level:
                typ = "RBS"
                break

        # PO2 is kept explicitly as a candidate, not falsely confirmed.
        if z["touches"] >= 2 and z["last_touch"] - z["first_touch"] >= 2:
            z["po2_candidate"] = True

        result.append({**z, "type": typ})

    return result

def liquidity_state(cs, level):
    if level is None or not cs:
        return {"sweep": False, "run": False, "direction": None}

    c = cs[-1]

    sweep = (
        (c.high > level and c.close <= level) or
        (c.low < level and c.close >= level)
    )

    run = c.close > level or c.close < level

    return {
        "sweep": sweep,
        "run": run,
        "direction": "UP" if c.close > level else ("DOWN" if c.close < level else None)
    }

def analyze(cs: List[Candle], timeframe: str, selected_level: Optional[float] = None):
    if not cs:
        return {"timeframe": timeframe, "status": "NO_DATA"}

    st = structure(cs)
    eg = engulfing(cs)
    zones = classify_zones(cs, level_candidates(cs))

    buys = [z for z in zones if z["type"] in BUY_ZONES]
    sells = [z for z in zones if z["type"] in SELL_ZONES]

    level = selected_level
    if level is None and zones:
        level = zones[0]["level"]

    liq = liquidity_state(cs, level)
    reasons = []

    if liq["sweep"]:
        reasons.append("Liquidity Sweep candidate")

    if liq["run"]:
        reasons.append("Liquidity Run / breakout candidate")

    if eg["bullish"]:
        reasons.append("Bullish Engulfing candidate")

    if eg["bearish"]:
        reasons.append("Bearish Engulfing candidate")

    if st["trend"] == "BULLISH" and buys:
        status = "BUY FRAMEWORK CANDIDATE"
    elif st["trend"] == "BEARISH" and sells:
        status = "SELL FRAMEWORK CANDIDATE"
    else:
        status = "WAIT / NO CONFIRMED SNRZ SETUP"

    return {
        "timeframe": timeframe,
        "status": status,
        "structure": st,
        "latest": asdict(cs[-1]),
        "engulfing": eg,
        "selected_level": level,
        "liquidity": liq,
        "zones": zones[:12],
        "buy_candidates": buys[:6],
        "sell_candidates": sells[:6],
        "reasons": reasons,
        "limitations": [
            "Zone labels are OHLC candidates unless all SNRZ confirmation evidence is available.",
            "PO2 is never treated as confirmed from touch count alone.",
            "No live trade execution; paper/educational analysis only."
        ]
    }

def multi_timeframe(all_candles: Dict[str, List[Candle]]):
    order = ["1mo", "1w", "1d", "4h", "1h", "30m", "15m", "5m", "1m"]
    out = {}

    for tf in order:
        if tf in all_candles:
            out[tf] = analyze(all_candles[tf], tf)

    trends = {
        tf: x.get("structure", {}).get("trend")
        for tf, x in out.items()
    }

    bull = sum(v == "BULLISH" for v in trends.values())
    bear = sum(v == "BEARISH" for v in trends.values())

    if bull > bear and bull >= 2:
        alignment = "BULLISH-LEANING"
    elif bear > bull and bear >= 2:
        alignment = "BEARISH-LEANING"
    else:
        alignment = "MIXED/UNCLEAR"

    return {
        "timeframes": out,
        "structure_alignment": alignment,
        "trend_counts": {
            "bullish": bull,
            "bearish": bear,
            "other": len(out) - bull - bear
        }
    }
